function val = polynomial_derivative(poly, x)

    n = length(poly);
    deg_deriv = n-2;
    poly_deriv = zeros(deg_deriv+1, 1);
    for ii=0:deg_deriv
        poly_deriv(ii+1) = poly(ii+2)*(ii+1);
    end
    
    val = polynomial_value(poly_deriv, x);
end