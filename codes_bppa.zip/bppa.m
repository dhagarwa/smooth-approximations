function g = bppa(f, ord, d, K, eps)
%This matlab code generates blended piecewise polynomial approximations
%Input is f, the set of values of f, on n points of uniform grid
%CALL bppa(f, ord, d, K, eps) with epsilon values and appropriate result
%will be obtained
    
    n = length(f);
    all_interp_points = linspace(0, 1, n); %Generating n-point uniform grid
    N = floor(n/(d + 1 - K)); %Finding the number of subintervals domain is to be divided
    interp_points_piecewise = cell(N, 1);  %array to store piecewise interpolation points
    interp_values_piecewise = cell(N, 1);  %array to store piecewise interpolation values
    for ii=1:N
        I = find(all_interp_points >= (ii - 1)/N & all_interp_points <= ii/N );
        %disp(all_interp_points(I));
        interp_points_piecewise{ii} = all_interp_points(I);
        interp_values_piecewise{ii} = f(I);
    end
    
    polynomial = zeros(N, d+1); %array to store piecewise polynomial interpolation
    for ii=1:N
        %For subinterval no. ii, choose total d+1 interpolation points from
        %interp_points_piecewise and neighbouring intervals
        %disp(interp_points_piecewise{ii});
        %disp(interp_values_piecewise{ii});
        if ii == 1
            current_interp_points = interp_points_piecewise{ii}(1: d+1-K);
            current_interp_points = [current_interp_points,  interp_points_piecewise{ii+1}(1:K)];
            current_interp_values = interp_values_piecewise{ii}(1: d+1-K);
            current_interp_values = [current_interp_values,  interp_values_piecewise{ii+1}(1:K)];
            
        elseif ii == N
            current_interp_points = interp_points_piecewise{ii}(1: d+1-K);
            current_interp_points = [current_interp_points,  interp_points_piecewise{ii-1}(1:K)];
            current_interp_values = interp_values_piecewise{ii}(1: d+1-K);
            current_interp_values = [current_interp_values,  interp_values_piecewise{ii-1}(1:K)];
            
        else
            current_interp_points = interp_points_piecewise{ii}(1: d+1-2*K);
            current_interp_points = [current_interp_points,  interp_points_piecewise{ii-1}(1:K), interp_points_piecewise{ii+1}(1:K)];
            current_interp_values = interp_values_piecewise{ii}(1: d+1-2*K);
            current_interp_values = [current_interp_values,  interp_values_piecewise{ii-1}(1:K), interp_values_piecewise{ii+1}(1:K)];            
    
        
        end
        %disp(current_interp_points);
        %disp(current_interp_values);
        V = fliplr(vander(current_interp_points));
        
        polynomial(ii, :) = V\current_interp_values';
        
        
        
    end
        
    disp(polynomial);
    %Store appropriate blending parameters
    blending_parameters = zeros(N-1, 2);
    for ii=1:N-1
        blending_parameters(ii, 1) = (-1 + eps/N + ii/N);
        blending_parameters(ii, 2) = (1 - eps/N + ii/N);
    end
    
    %Store points which fall in polynomial region
    polynomial_region = cell(N, 1);
    blending_region = cell(N-1, 1);
    approx = zeros(n, 1);
    approx_prime = zeros(n, 1);
    for ii = 1:N
        if ii==1
            I = find(all_interp_points >= (ii - 1)/N & all_interp_points <= (ii - eps)/N );
            
        elseif ii==N
            I = find(all_interp_points >= (ii - 1 + eps)/N & all_interp_points <= (ii)/N );
            
        else
            I = find(all_interp_points >= (ii - 1 + eps)/N & all_interp_points <= (ii - eps)/N );
        end
        polynomial_region{ii} = all_interp_points(I);
        
        for jj=1:length(I)
            approx(I(jj))= polynomial_value(polynomial(ii,:), all_interp_points(I(jj)));
            approx_prime(I(jj)) = polynomial_derivative(polynomial(ii, :), all_interp_points(I(jj)));
        end
    end
    %Store points which fall in blending region
    for ii=1:N-1
       I = find(all_interp_points > ((ii-eps)/N) & all_interp_points < ((ii+eps)/N));
       blending_region{ii} = all_interp_points(I);
       for jj=1:length(I)
           approx(I(jj))= blending_function(blending_parameters(ii, :), polynomial(ii, :), polynomial(ii+1, :), all_interp_points(I(jj)));
           approx_prime(I(jj)) = blending_function_derivative(blending_parameters(ii, :), polynomial(ii, :), polynomial(ii+1, :), all_interp_points(I(jj)));
       end
    end
    
    if ord==0
        g = approx;
    elseif ord==1
        g = approx_prime;
    end
end