function val = polynomial_value(poly, x)
    deg = length(poly) -1;
    val = 0;
    for ii = 0:deg
        val = val + poly(ii+1)* (x^(ii));
    end
    
end