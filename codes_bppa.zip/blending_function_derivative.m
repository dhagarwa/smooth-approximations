function val = blending_function_derivative(params, left_poly, right_poly, x)
%Blending function = (1 - phi(x))*p(x) + phi(x)*q(x)
%Blending function derivative = -phi'(x)*p(x) + (1-phi(x))*p'(x) +
%phi'(x)*q(x) + phi(x)*q'(x)

    val =  -(mollifier_derivative(params, x))* polynomial_value(left_poly,x)  + (1 - mollifier(params, x))* polynomial_derivative(left_poly, x) + mollifier_derivative(params, x)* polynomial_value(right_poly, x) + mollifier(params, x)*polynomial_derivative(right_poly, x);
    
   

end