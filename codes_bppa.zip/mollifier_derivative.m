function val = mollifier_derivative(params, x)
    a = params(1);
    b = params(2);
    val = (2*exp(1/(a^2+2*a*x+x^2-1)+1/(b^2+2*b*x+x^2-1))*(x *(1/((b+x)^2-1)^2-1/((a+x)^2-1)^2)-a/((a+x)^2-1)^2+b/((b+x)^2-1)^2))/(exp(1/(a^2+2*a*x+x^2-1))+exp(1/(b^2+2*b*x+x^2-1)))^2;

end