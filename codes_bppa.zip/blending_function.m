function val = blending_function(params, left_poly, right_poly, x)
    a = params(1);
    b = params(2);
    val = (1 - exp(-1/(1 - (x+a)^2))/(exp(-1/(1 - (x+a)^2)) + exp(-1/(1 - (x+b)^2))))* polynomial_value(left_poly, x) + (exp(-1/(1 - (x+a)^2))/(exp(-1/(1 - (x+a)^2)) + exp(-1/(1 - (x+b)^2))))*polynomial_value(right_poly, x);
    

end