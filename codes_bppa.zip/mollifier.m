function val = mollifier(params, x)
    a = params(1);
    b = params(2);
    val = exp(-1/(1 - (x+a)^2))/(exp(-1/(1 - (x+a)^2)) + exp(-1/(1 - (x+b)^2)));
end